<!DOCTYPE html>
<html>
<head>
    <title>Laravel 8 CKEditor Demo</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<style>
.hide {
        display: none;
}
.show:hover + .hide {
        display: none;
        display: block;
}
.price-wrapper{
  position: relative;
  display: inline-block;
}

.price-slash{
  position: relative;
  width: 100%;
  height: 0;
  border-top: 2px solid red;
  transform: rotate(-160deg);
  top: 17px;
}

.price{
    font-size: 25px;
}
</style>
<body>

<div class="container">
<div class="row">
    <br>
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Product Details</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="{{ url('posts') }}"> Back</a>
         </div>
    </div>
</div>

<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>product Title:</strong>
            {{ $post->title }}
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>product price:</strong>
            <div class="price-wrapper">
                <div class="price-slash"></div>
                <div class="price">{{ $post->actual_price }}</div>
              </div>
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>discounted price:</strong>
            <div class="price-wrapper">
                <div class="price">{{ $post->discounted_price }}</div>
              </div>
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>discount given:</strong>
            {{ $post->discount }} %
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Short Description:</strong>
            <td>
                <div class="show">{{ substr($post->s_body,0 ,99);}} </div><div class="hide">{{substr($post->s_body,99, 400);}} </div>
            </td>
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Image:</strong>
            <td><img src="/image/{{ $post->image }}" width="100px"></td>
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>long Description:</strong>
            <td> {!! html_entity_decode($post->body) !!} </td>
        </div>
    </div>
</div>
</div>

</body>
</html>


