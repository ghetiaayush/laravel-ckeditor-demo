<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;

class PostController extends Controller
{

    public function index() {

        $posts =  Post::orderBy("id", "ASC")->paginate(5);

        return view("posts", compact("posts"));
    }


    // Create Post
    public function create() {

        return view("create");
    }


    public function store(Request $request) {

       $selling_price = $request->actual_price - ($request->actual_price * $request->discount / 100);
       $post = [
                    "title"  =>  $request->title,
                    "s_body" => $request->s_body,
                    "actual_price"=>$request->actual_price,
                    "body" => $request->body,
                    "image"=> $request->image,
                    "discounted_price"=>$selling_price,
                    "discount"=> $request->discount,
                ];
        if ($image = $request->file('image')) {
            $destinationPath = 'image/';
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $post['image'] = "$profileImage";
        }

        //dd($post);

        Post::create($post);
        return back()->with("success", "Post has been created");

    }

    public function show(Post $post, $id)
    {
        $post = Post::find($id);
        //dd($post);
        return view("show", compact("post"));
    }
}
